
import { MonthlyReadingsForm } from "./MonthlyReadingsForm";

export function AccordionReadingForm() {
  return <MonthlyReadingsForm />;
}
